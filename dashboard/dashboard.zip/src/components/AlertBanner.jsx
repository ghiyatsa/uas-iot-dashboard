import PropTypes from 'prop-types';
import { SirenIcon } from './Icons';

export default function AlertBanner({ alert }) {
  const msg = alert?.message ?? 'Kondisi DANGER terdeteksi! Segera periksa ruangan.';

  return (
    <div className="alert-banner" role="alert" aria-live="assertive">
      <span className="alert-icon"><SirenIcon /></span>
      <div className="alert-body">
        <div className="alert-title">⚠ DANGER ALERT</div>
        <div className="alert-message">{msg}</div>
      </div>
      {alert?.gas_adc != null && (
        <span style={{
          fontFamily: 'var(--mono)',
          fontSize: '0.72rem',
          color: 'var(--danger)',
          borderLeft: '1px solid rgba(239,68,68,0.3)',
          paddingLeft: '12px',
          whiteSpace: 'nowrap',
        }}>
          Gas ADC<br />
          <strong style={{ fontSize: '1.1rem' }}>{alert.gas_adc}</strong>
        </span>
      )}
    </div>
  );
}

AlertBanner.propTypes = {
  alert: PropTypes.shape({
    message: PropTypes.string,
    gas_adc: PropTypes.number,
  }),
};
